<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use App\Models\ComplaintCategory;
use App\Models\Division;
use App\Models\District;
use App\Models\Organization;
use App\Models\Office;
use App\Models\OfficerProfile;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AdminDashboardController extends Controller
{
    /**
     * Executive Main Admin Dashboard
     */
    public function index()
    {
        $now = Carbon::now();
        $total = Complaint::count();
        $submitted = Complaint::where('current_status', 'submitted')->count();
        $underReview = Complaint::where('current_status', 'under_review')->count();
        $investigating = Complaint::whereIn('current_status', ['investigation_started', 'action_taken'])->count();
        $resolved = Complaint::whereIn('current_status', ['resolved', 'closed'])->count();
        $overdue = Complaint::where('current_status', 'overdue')
            ->orWhere(function ($q) use ($now) {
                $q->whereNotIn('current_status', ['resolved', 'closed', 'rejected'])
                  ->where('due_at', '<', $now);
            })->count();
        $escalated = Complaint::where('current_status', 'escalated')->count();

        // 6-Month Trend Data
        $monthlyTrend = [];
        for ($i = 5; $i >= 0; $i--) {
            $monthStart = Carbon::now()->subMonths($i)->startOfMonth();
            $monthEnd = Carbon::now()->subMonths($i)->endOfMonth();
            $monthName = $monthStart->format('M Y');

            $submittedCount = Complaint::whereBetween('created_at', [$monthStart, $monthEnd])->count();
            $resolvedCount = Complaint::whereBetween('resolved_at', [$monthStart, $monthEnd])->count();

            $monthlyTrend[] = [
                'month' => $monthName,
                'submitted' => $submittedCount,
                'resolved' => $resolvedCount,
            ];
        }

        // Category distribution
        $categoriesData = ComplaintCategory::withCount('complaints')
            ->orderByDesc('complaints_count')
            ->take(8)
            ->get()
            ->map(fn ($cat) => [
                'name' => $cat->name_bn,
                'count' => $cat->complaints_count,
            ]);

        // District distribution
        $districtsData = District::withCount('complaints')
            ->orderByDesc('complaints_count')
            ->take(6)
            ->get()
            ->map(fn ($d) => [
                'name' => $d->name_bn,
                'count' => $d->complaints_count,
            ]);

        // Organization Performance
        $organizationsData = Organization::where('status', 'active')
            ->withCount([
                'complaints',
                'complaints as resolved_count' => fn ($q) => $q->whereIn('current_status', ['resolved', 'closed']),
            ])
            ->take(6)
            ->get()
            ->map(fn ($org) => [
                'name' => $org->name_bn,
                'total' => $org->complaints_count,
                'resolved' => $org->resolved_count,
                'rate' => $org->complaints_count > 0 ? round(($org->resolved_count / $org->complaints_count) * 100, 1) : 0,
            ]);

        // Recent Audit Activity Feed
        $recentAudits = AuditLog::latest()->take(8)->get();

        return Inertia::render('Admin/Dashboard', [
            'metrics' => [
                'total' => $total,
                'submitted' => $submitted,
                'underReview' => $underReview,
                'investigating' => $investigating,
                'overdue' => $overdue,
                'escalated' => $escalated,
                'resolved' => $resolved,
                'resolutionRate' => $total > 0 ? round(($resolved / $total) * 100, 1) : 0,
            ],
            'monthlyTrend' => $monthlyTrend,
            'categoriesData' => $categoriesData,
            'districtsData' => $districtsData,
            'organizationsData' => $organizationsData,
            'recentAudits' => $recentAudits,
        ]);
    }

    /**
     * Interactive aggregate Map Dashboard
     */
    public function map(Request $request)
    {
        $divisions = Division::where('status', 'active')->with(['districts' => fn ($q) => $q->where('status', 'active')])->get();
        $categories = ComplaintCategory::where('status', 'active')->get();

        $query = Complaint::with(['district', 'category', 'organization']);

        if ($request->filled('division_id')) {
            $query->where('division_id', $request->division_id);
        }
        if ($request->filled('district_id')) {
            $query->where('district_id', $request->district_id);
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('status')) {
            $query->where('current_status', $request->status);
        }

        $complaints = $query->take(300)->get();

        // Aggregate by district with lat/lng
        $districtAggregates = District::whereNotNull('lat')->whereNotNull('lng')
            ->withCount(['complaints as total_complaints'])
            ->get()
            ->map(fn ($d) => [
                'id' => $d->id,
                'name_bn' => $d->name_bn,
                'name_en' => $d->name_en,
                'lat' => $d->lat,
                'lng' => $d->lng,
                'count' => $d->total_complaints,
            ]);

        return Inertia::render('Admin/Map', [
            'divisions' => $divisions,
            'categories' => $categories,
            'districtAggregates' => $districtAggregates,
            'filters' => $request->only(['division_id', 'district_id', 'category_id', 'status']),
        ]);
    }

    /**
     * Global Search across Complaints, Organizations, Officers, and Geography
     */
    public function globalSearch(Request $request)
    {
        $q = trim($request->query('q', ''));
        if (strlen($q) < 2) {
            return response()->json(['results' => []]);
        }

        $complaints = Complaint::where('tracking_id', 'like', "%{$q}%")
            ->orWhere('title', 'like', "%{$q}%")
            ->take(5)
            ->get(['id', 'tracking_id', 'title', 'current_status']);

        $organizations = Organization::where('name_bn', 'like', "%{$q}%")
            ->orWhere('name_en', 'like', "%{$q}%")
            ->take(5)
            ->get(['id', 'name_bn', 'name_en']);

        $officers = OfficerProfile::where('name_bn', 'like', "%{$q}%")
            ->orWhere('name_en', 'like', "%{$q}%")
            ->orWhere('designation_bn', 'like', "%{$q}%")
            ->take(5)
            ->get(['id', 'name_bn', 'designation_bn']);

        return response()->json([
            'complaints' => $complaints,
            'organizations' => $organizations,
            'officers' => $officers,
        ]);
    }
}
