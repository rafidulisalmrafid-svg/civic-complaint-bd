<?php

namespace Database\Seeders;

use App\Models\Division;
use App\Models\District;
use App\Models\Upazila;
use App\Models\LocalGovernment;
use App\Models\Ward;
use App\Models\Area;
use App\Models\PostOffice;
use Illuminate\Database\Seeder;

class GeographySeeder extends Seeder
{
    public function run(): void
    {
        // 1. All 8 Divisions
        $divisionsData = [
            ['name_bn' => 'বরিশাল', 'name_en' => 'Barishal', 'code' => 'BARISHAL'],
            ['name_bn' => 'চট্টগ্রাম', 'name_en' => 'Chattogram', 'code' => 'CHATTOGRAM'],
            ['name_bn' => 'ঢাকা', 'name_en' => 'Dhaka', 'code' => 'DHAKA'],
            ['name_bn' => 'খুলনা', 'name_en' => 'Khulna', 'code' => 'KHULNA'],
            ['name_bn' => 'রাজশাহী', 'name_en' => 'Rajshahi', 'code' => 'RAJSHAHI'],
            ['name_bn' => 'রংপুর', 'name_en' => 'Rangpur', 'code' => 'RANGPUR'],
            ['name_bn' => 'সিলেট', 'name_en' => 'Sylhet', 'code' => 'SYLHET'],
            ['name_bn' => 'ময়মনসিংহ', 'name_en' => 'Mymensingh', 'code' => 'MYMENSINGH'],
        ];

        $divisions = [];
        foreach ($divisionsData as $item) {
            $divisions[$item['code']] = Division::create($item);
        }

        // 2. Districts (Focus on Barishal and Cumilla + major others)
        $districtsData = [
            ['division_id' => $divisions['BARISHAL']->id, 'name_bn' => 'বরিশাল', 'name_en' => 'Barishal', 'code' => 'BARISHAL_DIST', 'lat' => 22.7010, 'lng' => 90.3535],
            ['division_id' => $divisions['BARISHAL']->id, 'name_bn' => 'পটুয়াখালী', 'name_en' => 'Patuakhali', 'code' => 'PATUAKHALI_DIST', 'lat' => 22.3596, 'lng' => 90.3299],
            ['division_id' => $divisions['BARISHAL']->id, 'name_bn' => 'ভোলা', 'name_en' => 'Bhola', 'code' => 'BHOLA_DIST', 'lat' => 22.6859, 'lng' => 90.6481],
            ['division_id' => $divisions['CHATTOGRAM']->id, 'name_bn' => 'কুমিল্লা', 'name_en' => 'Cumilla', 'code' => 'CUMILLA_DIST', 'lat' => 23.4607, 'lng' => 91.1809],
            ['division_id' => $divisions['CHATTOGRAM']->id, 'name_bn' => 'চট্টগ্রাম', 'name_en' => 'Chattogram', 'code' => 'CHATTOGRAM_DIST', 'lat' => 22.3569, 'lng' => 91.7832],
            ['division_id' => $divisions['CHATTOGRAM']->id, 'name_bn' => 'কক্সবাজার', 'name_en' => 'Cox\'s Bazar', 'code' => 'COXBZ_DIST', 'lat' => 21.4272, 'lng' => 92.0058],
            ['division_id' => $divisions['DHAKA']->id, 'name_bn' => 'ঢাকা', 'name_en' => 'Dhaka', 'code' => 'DHAKA_DIST', 'lat' => 23.8103, 'lng' => 90.4125],
            ['division_id' => $divisions['DHAKA']->id, 'name_bn' => 'গাজীপুর', 'name_en' => 'Gazipur', 'code' => 'GAZIPUR_DIST', 'lat' => 23.9999, 'lng' => 90.4203],
            ['division_id' => $divisions['KHULNA']->id, 'name_bn' => 'খুলনা', 'name_en' => 'Khulna', 'code' => 'KHULNA_DIST', 'lat' => 22.8456, 'lng' => 89.5403],
            ['division_id' => $divisions['RAJSHAHI']->id, 'name_bn' => 'রাজশাহী', 'name_en' => 'Rajshahi', 'code' => 'RAJSHAHI_DIST', 'lat' => 24.3745, 'lng' => 88.6042],
            ['division_id' => $divisions['SYLHET']->id, 'name_bn' => 'সিলেট', 'name_en' => 'Sylhet', 'code' => 'SYLHET_DIST', 'lat' => 24.8949, 'lng' => 91.8687],
        ];

        $districts = [];
        foreach ($districtsData as $item) {
            $districts[$item['code']] = District::create($item);
        }

        // 3. Upazilas for Barishal District (All 9 Upazilas)
        $barishalUpazilas = [
            ['name_bn' => 'বরিশাল সদর', 'name_en' => 'Barishal Sadar', 'lat' => 22.7010, 'lng' => 90.3535],
            ['name_bn' => 'বাবুগঞ্জ', 'name_en' => 'Babuganj', 'lat' => 22.8291, 'lng' => 90.3204],
            ['name_bn' => 'বাকেরগঞ্জ', 'name_en' => 'Bakerganj', 'lat' => 22.5516, 'lng' => 90.3396],
            ['name_bn' => 'বানারীপাড়া', 'name_en' => 'Banaripara', 'lat' => 22.7797, 'lng' => 90.1650],
            ['name_bn' => 'গৌরনদী', 'name_en' => 'Gournadi', 'lat' => 22.9734, 'lng' => 90.2312],
            ['name_bn' => 'হিজলা', 'name_en' => 'Hizla', 'lat' => 22.9080, 'lng' => 90.5098],
            ['name_bn' => 'মেহেন্দিগঞ্জ', 'name_en' => 'Mehendiganj', 'lat' => 22.8272, 'lng' => 90.5312],
            ['name_bn' => 'মুলাদী', 'name_en' => 'Muladi', 'lat' => 22.9150, 'lng' => 90.4150],
            ['name_bn' => 'উজিরপুর', 'name_en' => 'Wazirpur', 'lat' => 22.8105, 'lng' => 90.2440],
        ];

        $upazilasMap = [];
        foreach ($barishalUpazilas as $u) {
            $created = Upazila::create([
                'district_id' => $districts['BARISHAL_DIST']->id,
                'name_bn' => $u['name_bn'],
                'name_en' => $u['name_en'],
                'lat' => $u['lat'],
                'lng' => $u['lng'],
            ]);
            $upazilasMap['BAR_' . $u['name_en']] = $created;
        }

        // 4. Upazilas for Cumilla District
        $cumillaUpazilas = [
            ['name_bn' => 'আদর্শ সদর', 'name_en' => 'Adarsha Sadar', 'lat' => 23.4607, 'lng' => 91.1809],
            ['name_bn' => 'সদর দক্ষিণ', 'name_en' => 'Sadar Dakshin', 'lat' => 23.3850, 'lng' => 91.1710],
            ['name_bn' => 'দাউদকান্দি', 'name_en' => 'Daudkandi', 'lat' => 23.5333, 'lng' => 90.7167],
            ['name_bn' => 'চান্দিনা', 'name_en' => 'Chandina', 'lat' => 23.4833, 'lng' => 90.9833],
            ['name_bn' => 'দেবীদ্বার', 'name_en' => 'Debidwar', 'lat' => 23.6000, 'lng' => 90.9833],
            ['name_bn' => 'মুরাদনগর', 'name_en' => 'Muradnagar', 'lat' => 23.6333, 'lng' => 90.9333],
            ['name_bn' => 'লাকসাম', 'name_en' => 'Laksham', 'lat' => 23.2417, 'lng' => 91.1250],
            ['name_bn' => 'চৌদ্দগ্রাম', 'name_en' => 'Chauddagram', 'lat' => 23.2167, 'lng' => 91.3167],
        ];

        foreach ($cumillaUpazilas as $u) {
            $created = Upazila::create([
                'district_id' => $districts['CUMILLA_DIST']->id,
                'name_bn' => $u['name_bn'],
                'name_en' => $u['name_en'],
                'lat' => $u['lat'],
                'lng' => $u['lng'],
            ]);
            $upazilasMap['CUM_' . $u['name_en']] = $created;
        }

        // Dhaka Sadar for reference
        $dhakaSadar = Upazila::create([
            'district_id' => $districts['DHAKA_DIST']->id,
            'name_bn' => 'ধানমন্ডি',
            'name_en' => 'Dhanmondi',
            'lat' => 23.7461,
            'lng' => 90.3742,
        ]);
        $upazilasMap['DHK_Dhanmondi'] = $dhakaSadar;

        // 5. Local Governments
        // Barishal City Corporation (under Barishal Sadar)
        $bcc = LocalGovernment::create([
            'upazila_id' => $upazilasMap['BAR_Barishal Sadar']->id,
            'name_bn' => 'বরিশাল সিটি কর্পোরেশন',
            'name_en' => 'Barishal City Corporation',
            'type' => 'city_corporation',
            'code' => 'BCC',
        ]);

        // Gournadi Pourashava
        $gournadiPoura = LocalGovernment::create([
            'upazila_id' => $upazilasMap['BAR_Gournadi']->id,
            'name_bn' => 'গৌরনদী পৌরসভা',
            'name_en' => 'Gournadi Pourashava',
            'type' => 'pourashava',
            'code' => 'GP',
        ]);

        // Kashipur Union Parishad
        $kashipurUnion = LocalGovernment::create([
            'upazila_id' => $upazilasMap['BAR_Barishal Sadar']->id,
            'name_bn' => 'কাশিপুর ইউনিয়ন পরিষদ',
            'name_en' => 'Kashipur Union Parishad',
            'type' => 'union_parishad',
            'code' => 'KUP',
        ]);

        // Cumilla City Corporation (under Adarsha Sadar)
        $cocc = LocalGovernment::create([
            'upazila_id' => $upazilasMap['CUM_Adarsha Sadar']->id,
            'name_bn' => 'কুমিল্লা সিটি কর্পোরেশন',
            'name_en' => 'Cumilla City Corporation',
            'type' => 'city_corporation',
            'code' => 'COCC',
        ]);

        // Laksham Pourashava
        $lakshamPoura = LocalGovernment::create([
            'upazila_id' => $upazilasMap['CUM_Laksham']->id,
            'name_bn' => 'লাকসাম পৌরসভা',
            'name_en' => 'Laksham Pourashava',
            'type' => 'pourashava',
            'code' => 'LP',
        ]);

        // 6. Wards for Barishal City Corporation (Wards 01 to 30)
        $bccWards = [];
        for ($i = 1; $i <= 30; $i++) {
            $numStr = str_pad((string)$i, 2, '0', STR_PAD_LEFT);
            $bccWards[$i] = Ward::create([
                'local_government_id' => $bcc->id,
                'ward_number' => $numStr,
                'name_bn' => "ওয়ার্ড নং {$numStr} (বিসিসি)",
                'name_en' => "Ward {$numStr} (BCC)",
            ]);
        }

        // Wards for Cumilla City Corporation (Wards 01 to 27)
        $coccWards = [];
        for ($i = 1; $i <= 27; $i++) {
            $numStr = str_pad((string)$i, 2, '0', STR_PAD_LEFT);
            $coccWards[$i] = Ward::create([
                'local_government_id' => $cocc->id,
                'ward_number' => $numStr,
                'name_bn' => "ওয়ার্ড নং {$numStr} (কুসিক)",
                'name_en' => "Ward {$numStr} (COCC)",
            ]);
        }

        // Wards for Gournadi Pourashava (Wards 01 to 09)
        for ($i = 1; $i <= 9; $i++) {
            $numStr = str_pad((string)$i, 2, '0', STR_PAD_LEFT);
            Ward::create([
                'local_government_id' => $gournadiPoura->id,
                'ward_number' => $numStr,
                'name_bn' => "ওয়ার্ড নং {$numStr} (গৌরনদী)",
                'name_en' => "Ward {$numStr} (Gournadi)",
            ]);
        }

        // 7. Prominent Areas / Mohallas
        // Barishal Areas
        $barishalAreas = [
            ['ward_id' => $bccWards[10]->id, 'name_bn' => 'ব্যান্ড রোড', 'name_en' => 'Band Road', 'type' => 'road'],
            ['ward_id' => $bccWards[10]->id, 'name_bn' => 'লঞ্চ ঘাট এলাকা', 'name_en' => 'Launch Ghat', 'type' => 'mohalla'],
            ['ward_id' => $bccWards[1]->id, 'name_bn' => 'নথুল্লাবাদ কেন্দ্রীয় বাস টার্মিনাল', 'name_en' => 'Nathullabad', 'type' => 'mohalla'],
            ['ward_id' => $bccWards[25]->id, 'name_bn' => 'রূপাতলী হাউজিং', 'name_en' => 'Rupatali Housing', 'type' => 'mohalla'],
            ['ward_id' => $bccWards[12]->id, 'name_bn' => 'সিঅ্যান্ডবি রোড', 'name_en' => 'C&B Road', 'type' => 'road'],
            ['ward_id' => $bccWards[14]->id, 'name_bn' => 'চৌমাথা', 'name_en' => 'Chaumatha', 'type' => 'mohalla'],
            ['ward_id' => $bccWards[20]->id, 'name_bn' => 'আলেকান্দা', 'name_en' => 'Alekanda', 'type' => 'village'],
            ['ward_id' => $bccWards[5]->id, 'name_bn' => 'আমানতগঞ্জ', 'name_en' => 'Amanatganj', 'type' => 'village'],
        ];
        foreach ($barishalAreas as $a) {
            Area::create($a);
        }

        // Cumilla Areas
        $cumillaAreas = [
            ['ward_id' => $coccWards[11]->id, 'name_bn' => 'কান্দিরপাড়', 'name_en' => 'Kandirpar', 'type' => 'mohalla'],
            ['ward_id' => $coccWards[10]->id, 'name_bn' => 'বাদুরতলা', 'name_en' => 'Badurtala', 'type' => 'mohalla'],
            ['ward_id' => $coccWards[15]->id, 'name_bn' => 'টমছম ব্রিজ', 'name_en' => 'Tomsom Bridge', 'type' => 'mohalla'],
            ['ward_id' => $coccWards[1]->id, 'name_bn' => 'শাসনগাছা বাস টার্মিনাল', 'name_en' => 'Shasongachha', 'type' => 'mohalla'],
            ['ward_id' => $coccWards[12]->id, 'name_bn' => 'ধর্মসাগর পশ্চিম পাড়', 'name_en' => 'Dharmasagar Par', 'type' => 'road'],
            ['ward_id' => $coccWards[8]->id, 'name_bn' => 'ঝাউতলা', 'name_en' => 'Jhawtola', 'type' => 'mohalla'],
            ['ward_id' => $coccWards[20]->id, 'name_bn' => 'চকবাজার', 'name_en' => 'Chawkbazar', 'type' => 'mohalla'],
        ];
        foreach ($cumillaAreas as $a) {
            Area::create($a);
        }

        // 8. Post Offices
        $postOffices = [
            // Barishal
            ['upazila_id' => $upazilasMap['BAR_Barishal Sadar']->id, 'name_bn' => 'বরিশাল প্রধান ডাকঘর', 'name_en' => 'Barishal Head Post Office', 'post_code' => '8200'],
            ['upazila_id' => $upazilasMap['BAR_Barishal Sadar']->id, 'name_bn' => 'নথুল্লাবাদ উপ-ডাকঘর', 'name_en' => 'Nathullabad Sub-PO', 'post_code' => '8201'],
            ['upazila_id' => $upazilasMap['BAR_Barishal Sadar']->id, 'name_bn' => 'রূপাতলী উপ-ডাকঘর', 'name_en' => 'Rupatali Sub-PO', 'post_code' => '8202'],
            ['upazila_id' => $upazilasMap['BAR_Gournadi']->id, 'name_bn' => 'গৌরনদী পোস্ট অফিস', 'name_en' => 'Gournadi Post Office', 'post_code' => '8230'],
            ['upazila_id' => $upazilasMap['BAR_Bakerganj']->id, 'name_bn' => 'বাকেরগঞ্জ পোস্ট অফিস', 'name_en' => 'Bakerganj Post Office', 'post_code' => '8280'],

            // Cumilla
            ['upazila_id' => $upazilasMap['CUM_Adarsha Sadar']->id, 'name_bn' => 'কুমিল্লা প্রধান ডাকঘর', 'name_en' => 'Cumilla Head Post Office', 'post_code' => '3500'],
            ['upazila_id' => $upazilasMap['CUM_Adarsha Sadar']->id, 'name_bn' => 'কান্দিরপাড় উপ-ডাকঘর', 'name_en' => 'Kandirpar Sub-PO', 'post_code' => '3501'],
            ['upazila_id' => $upazilasMap['CUM_Adarsha Sadar']->id, 'name_bn' => 'টমছম ব্রিজ উপ-ডাকঘর', 'name_en' => 'Tomsom Bridge Sub-PO', 'post_code' => '3502'],
            ['upazila_id' => $upazilasMap['CUM_Laksham']->id, 'name_bn' => 'লাকসাম পোস্ট অফিস', 'name_en' => 'Laksham Post Office', 'post_code' => '3570'],
            ['upazila_id' => $upazilasMap['CUM_Daudkandi']->id, 'name_bn' => 'দাউদকান্দি পোস্ট অফিস', 'name_en' => 'Daudkandi Post Office', 'post_code' => '3516'],
        ];

        foreach ($postOffices as $p) {
            PostOffice::create($p);
        }
    }
}
