<?php

namespace Database\Seeders;

use App\Models\OrganizationType;
use App\Models\Organization;
use App\Models\Office;
use App\Models\OfficerProfile;
use App\Models\District;
use App\Models\Upazila;
use App\Models\User;
use Illuminate\Database\Seeder;

class OrganizationSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Organization Types
        $ministryType = OrganizationType::create(['name_bn' => 'মন্ত্রণালয়', 'name_en' => 'Ministry', 'slug' => 'ministry', 'level_order' => 1]);
        $directorateType = OrganizationType::create(['name_bn' => 'অধিদপ্তর / পরিদপ্তর', 'name_en' => 'Directorate', 'slug' => 'directorate', 'level_order' => 2]);
        $agencyType = OrganizationType::create(['name_bn' => 'সংস্থা / বোর্ড / কর্পোরেশন', 'name_en' => 'Agency/Board', 'slug' => 'agency', 'level_order' => 3]);
        $fieldOfficeType = OrganizationType::create(['name_bn' => 'মাঠ পর্যায়ের কার্যালয়', 'name_en' => 'Field Office', 'slug' => 'field_office', 'level_order' => 4]);

        // 2. Organizations
        // LGRD
        $lgrd = Organization::create([
            'organization_type_id' => $ministryType->id,
            'name_bn' => 'স্থানীয় সরকার বিভাগ (এলজিআরডি)',
            'name_en' => 'Local Government Division',
            'code' => 'LGD',
            'email' => 'secretary@lgd.gov.bd',
            'phone' => '02-9512345',
            'website' => 'https://lgd.gov.bd',
            'icon' => 'building-2',
        ]);

        // Land Ministry
        $landMinistry = Organization::create([
            'organization_type_id' => $ministryType->id,
            'name_bn' => 'ভূমি মন্ত্রণালয়',
            'name_en' => 'Ministry of Land',
            'code' => 'MINLAND',
            'email' => 'info@minland.gov.bd',
            'phone' => '16122',
            'website' => 'https://minland.gov.bd',
            'icon' => 'map-pin',
        ]);

        // Health Ministry & DGHS
        $healthMinistry = Organization::create([
            'organization_type_id' => $ministryType->id,
            'name_bn' => 'স্বাস্থ্য ও পরিবার কল্যাণ মন্ত্রণালয়',
            'name_en' => 'Ministry of Health and Family Welfare',
            'code' => 'MOHFW',
            'email' => 'info@mohfw.gov.bd',
            'website' => 'https://mohfw.gov.bd',
            'icon' => 'activity',
        ]);

        $dghs = Organization::create([
            'parent_id' => $healthMinistry->id,
            'organization_type_id' => $directorateType->id,
            'name_bn' => 'স্বাস্থ্য অধিদপ্তর (ডিজিএইচএস)',
            'name_en' => 'Directorate General of Health Services',
            'code' => 'DGHS',
            'email' => 'info@dghs.gov.bd',
            'website' => 'https://dghs.gov.bd',
            'icon' => 'shield-plus',
        ]);

        // Power Board
        $powerMinistry = Organization::create([
            'organization_type_id' => $ministryType->id,
            'name_bn' => 'বিদ্যুৎ, জ্বালানি ও খনিজ সম্পদ মন্ত্রণালয়',
            'name_en' => 'Ministry of Power, Energy and Mineral Resources',
            'code' => 'MPEMR',
            'icon' => 'zap',
        ]);

        $bpdb = Organization::create([
            'parent_id' => $powerMinistry->id,
            'organization_type_id' => $agencyType->id,
            'name_bn' => 'বাংলাদেশ বিদ্যুৎ উন্নয়ন বোর্ড (বিউবো)',
            'name_en' => 'Bangladesh Power Development Board',
            'code' => 'BPDB',
            'icon' => 'zap',
        ]);

        // Environment
        $doe = Organization::create([
            'organization_type_id' => $directorateType->id,
            'name_bn' => 'পরিবেশ অধিদপ্তর',
            'name_en' => 'Department of Environment',
            'code' => 'DOE',
            'icon' => 'leaf',
        ]);

        // Police
        $police = Organization::create([
            'organization_type_id' => $agencyType->id,
            'name_bn' => 'বাংলাদেশ পুলিশ',
            'name_en' => 'Bangladesh Police',
            'code' => 'BD_POLICE',
            'icon' => 'shield',
        ]);

        // Roads
        $rhd = Organization::create([
            'organization_type_id' => $directorateType->id,
            'name_bn' => 'সড়ক ও জনপথ অধিদপ্তর (সওজ)',
            'name_en' => 'Roads and Highways Department',
            'code' => 'RHD',
            'icon' => 'truck',
        ]);

        // 3. Offices in Barishal & Cumilla
        $barishalDist = District::where('code', 'BARISHAL_DIST')->first();
        $cumillaDist = District::where('code', 'CUMILLA_DIST')->first();
        $barishalSadar = Upazila::where('name_en', 'Barishal Sadar')->first();
        $cumillaSadar = Upazila::where('name_en', 'Adarsha Sadar')->first();

        // Office 1: Barishal District Civil Surgeon Office
        $barishalCivilSurgeonOffice = Office::create([
            'organization_id' => $dghs->id,
            'name_bn' => 'সিভিল সার্জন কার্যালয়, বরিশাল',
            'name_en' => 'Civil Surgeon Office, Barishal',
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'address' => 'ব্যান্ড রোড, বরিশাল সদর, বরিশাল',
            'phone' => '0431-2173456',
            'email' => 'csbarishal@dghs.gov.bd',
        ]);

        // Office 2: Barishal Sadar AC Land Office
        $barishalAcLandOffice = Office::create([
            'organization_id' => $landMinistry->id,
            'name_bn' => 'উপজেলা ভূমি অফিস, বরিশাল সদর',
            'name_en' => 'Upazila Land Office, Barishal Sadar',
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'address' => 'কালেক্টরেট চত্বর, বরিশাল সদর',
            'phone' => '0431-64532',
            'email' => 'acland.barishal@minland.gov.bd',
        ]);

        // Office 3: BPDB Barishal Division
        $bpdbBarishalOffice = Office::create([
            'organization_id' => $bpdb->id,
            'name_bn' => 'বিদ্যুৎ বিক্রয় ও বিতরণ বিভাগ-১, ওজোপাডিকো, বরিশাল',
            'name_en' => 'BPDB / WZPDCL Distribution Division 1, Barishal',
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'address' => 'পলাশপুর মোড়, বরিশাল',
            'phone' => '0431-71234',
        ]);

        // Office 4: Cumilla City Corporation Engineering Dept
        $cumillaEngOffice = Office::create([
            'organization_id' => $lgrd->id,
            'name_bn' => 'প্রকৌশল বিভাগ, কুমিল্লা সিটি কর্পোরেশন',
            'name_en' => 'Engineering Department, Cumilla City Corporation',
            'district_id' => $cumillaDist->id,
            'upazila_id' => $cumillaSadar->id,
            'address' => 'কান্দিরপাড়, কুমিল্লা',
            'phone' => '081-65432',
            'email' => 'engg@cocc.gov.bd',
        ]);

        // Office 5: Cumilla Civil Surgeon Office
        $cumillaCivilSurgeonOffice = Office::create([
            'organization_id' => $dghs->id,
            'name_bn' => 'সিভিল সার্জন কার্যালয়, কুমিল্লা',
            'name_en' => 'Civil Surgeon Office, Cumilla',
            'district_id' => $cumillaDist->id,
            'upazila_id' => $cumillaSadar->id,
            'address' => 'টমছম ব্রিজ রোড, কুমিল্লা',
            'phone' => '081-76543',
        ]);

        // 4. Officer Profiles
        // Link with officer user accounts created in UserSeeder
        $userOfficerBarishal = User::where('email', 'officer@barishal.gov.bd')->first();
        $userOfficerCumilla = User::where('email', 'officer@cumilla.gov.bd')->first();
        $userAcLand = User::where('email', 'acland@barishal.gov.bd')->first();

        OfficerProfile::create([
            'user_id' => $userOfficerBarishal?->id,
            'employee_id' => 'DGHS-BAR-001',
            'name_bn' => 'ডা. মারুফ হাসান',
            'name_en' => 'Dr. Maruf Hasan',
            'designation_bn' => 'সিভিল সার্জন',
            'designation_en' => 'Civil Surgeon',
            'official_phone' => '01800000000',
            'official_email' => 'officer@barishal.gov.bd',
            'organization_id' => $dghs->id,
            'office_id' => $barishalCivilSurgeonOffice->id,
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'joining_date' => '2022-03-15',
            'status' => 'active',
        ]);

        OfficerProfile::create([
            'user_id' => $userAcLand?->id,
            'employee_id' => 'BCS-LAND-042',
            'name_bn' => 'নুসরাত জাহান',
            'name_en' => 'Nusrat Jahan',
            'designation_bn' => 'সহকারী কমিশনার (ভূমি)',
            'designation_en' => 'Assistant Commissioner (Land)',
            'official_phone' => '01600000000',
            'official_email' => 'acland@barishal.gov.bd',
            'organization_id' => $landMinistry->id,
            'office_id' => $barishalAcLandOffice->id,
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'joining_date' => '2023-08-01',
            'status' => 'active',
        ]);

        OfficerProfile::create([
            'user_id' => $userOfficerCumilla?->id,
            'employee_id' => 'COCC-ENG-108',
            'name_bn' => 'মোঃ জহিরুল ইসলাম',
            'name_en' => 'Md. Zahirul Islam',
            'designation_bn' => 'নির্বাহী প্রকৌশলী (পূর্ত)',
            'designation_en' => 'Executive Engineer (Civil)',
            'official_phone' => '01900000000',
            'official_email' => 'officer@cumilla.gov.bd',
            'organization_id' => $lgrd->id,
            'office_id' => $cumillaEngOffice->id,
            'district_id' => $cumillaDist->id,
            'upazila_id' => $cumillaSadar->id,
            'joining_date' => '2021-11-20',
            'status' => 'active',
        ]);

        // Add additional officer without login account (demonstrating directory vs login separation)
        OfficerProfile::create([
            'user_id' => null, // No login yet
            'employee_id' => 'WZPDCL-ENG-502',
            'name_bn' => 'প্রকৌশলী তানজিম আহমেদ',
            'name_en' => 'Engr. Tanjim Ahmed',
            'designation_bn' => 'উপ-বিভাগীয় প্রকৌশলী',
            'designation_en' => 'Sub-Divisional Engineer',
            'official_phone' => '01712345678',
            'official_email' => 'sde.barishal@wzpdcl.gov.bd',
            'organization_id' => $bpdb->id,
            'office_id' => $bpdbBarishalOffice->id,
            'district_id' => $barishalDist->id,
            'upazila_id' => $barishalSadar->id,
            'joining_date' => '2024-01-10',
            'status' => 'active',
        ]);
    }
}
