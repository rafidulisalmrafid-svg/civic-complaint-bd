import React, { useState, useEffect } from 'react';
import { MapPin, Loader2 } from 'lucide-react';

export default function LocationSelector({
    divisions = [],
    selectedValues = {},
    onChange,
    errors = {},
}) {
    const [districts, setDistricts] = useState([]);
    const [upazilas, setUpazilas] = useState([]);
    const [localGovs, setLocalGovs] = useState([]);
    const [wards, setWards] = useState([]);
    const [areas, setAreas] = useState([]);
    const [postOffices, setPostOffices] = useState([]);

    const [loadingDistrict, setLoadingDistrict] = useState(false);
    const [loadingUpazila, setLoadingUpazila] = useState(false);
    const [loadingLocalGov, setLoadingLocalGov] = useState(false);
    const [loadingWard, setLoadingWard] = useState(false);
    const [loadingArea, setLoadingArea] = useState(false);

    // Load districts on division change
    useEffect(() => {
        if (!selectedValues.division_id) {
            setDistricts([]);
            return;
        }
        setLoadingDistrict(true);
        fetch(`/api/geo/districts/${selectedValues.division_id}`)
            .then(res => res.json())
            .then(data => {
                setDistricts(data);
                setLoadingDistrict(false);
            })
            .catch(() => setLoadingDistrict(false));
    }, [selectedValues.division_id]);

    // Load upazilas on district change
    useEffect(() => {
        if (!selectedValues.district_id) {
            setUpazilas([]);
            return;
        }
        setLoadingUpazila(true);
        fetch(`/api/geo/upazilas/${selectedValues.district_id}`)
            .then(res => res.json())
            .then(data => {
                setUpazilas(data);
                setLoadingUpazila(false);
            })
            .catch(() => setLoadingUpazila(false));
    }, [selectedValues.district_id]);

    // Load Local Governments & Post Offices on upazila change
    useEffect(() => {
        if (!selectedValues.upazila_id) {
            setLocalGovs([]);
            setPostOffices([]);
            return;
        }
        setLoadingLocalGov(true);
        Promise.all([
            fetch(`/api/geo/local-governments/${selectedValues.upazila_id}`).then(r => r.json()),
            fetch(`/api/geo/post-offices/${selectedValues.upazila_id}`).then(r => r.json()),
        ]).then(([lgData, poData]) => {
            setLocalGovs(lgData);
            setPostOffices(poData);
            setLoadingLocalGov(false);
        }).catch(() => setLoadingLocalGov(false));
    }, [selectedValues.upazila_id]);

    // Load Wards on Local Government change
    useEffect(() => {
        if (!selectedValues.local_government_id) {
            setWards([]);
            return;
        }
        setLoadingWard(true);
        fetch(`/api/geo/wards/${selectedValues.local_government_id}`)
            .then(res => res.json())
            .then(data => {
                setWards(data);
                setLoadingWard(false);
            })
            .catch(() => setLoadingWard(false));
    }, [selectedValues.local_government_id]);

    // Load Areas on Ward change
    useEffect(() => {
        if (!selectedValues.ward_id) {
            setAreas([]);
            return;
        }
        setLoadingArea(true);
        fetch(`/api/geo/areas/${selectedValues.ward_id}`)
            .then(res => res.json())
            .then(data => {
                setAreas(data);
                setLoadingArea(false);
            })
            .catch(() => setLoadingArea(false));
    }, [selectedValues.ward_id]);

    return (
        <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Division */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                        বিভাগ <span className="text-red-500">*</span>
                    </label>
                    <select
                        value={selectedValues.division_id || ''}
                        onChange={e => {
                            onChange('division_id', e.target.value);
                            onChange('district_id', '');
                            onChange('upazila_id', '');
                            onChange('local_government_id', '');
                            onChange('ward_id', '');
                        }}
                        className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white"
                    >
                        <option value="">বিভাগ নির্বাচন করুন</option>
                        {divisions.map(div => (
                            <option key={div.id} value={div.id}>{div.name_bn}</option>
                        ))}
                    </select>
                    {errors.division_id && <p className="text-xs text-red-600 mt-1">{errors.division_id}</p>}
                </div>

                {/* District */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                        <span>জেলা <span className="text-red-500">*</span></span>
                        {loadingDistrict && <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />}
                    </label>
                    <select
                        value={selectedValues.district_id || ''}
                        disabled={!selectedValues.division_id || loadingDistrict}
                        onChange={e => {
                            onChange('district_id', e.target.value);
                            onChange('upazila_id', '');
                            onChange('local_government_id', '');
                            onChange('ward_id', '');
                        }}
                        className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white disabled:bg-slate-100 disabled:text-slate-400"
                    >
                        <option value="">জেলা নির্বাচন করুন</option>
                        {districts.map(d => (
                            <option key={d.id} value={d.id}>{d.name_bn}</option>
                        ))}
                    </select>
                    {errors.district_id && <p className="text-xs text-red-600 mt-1">{errors.district_id}</p>}
                </div>

                {/* Upazila */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                        <span>উপজেলা / থানা <span className="text-red-500">*</span></span>
                        {loadingUpazila && <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />}
                    </label>
                    <select
                        value={selectedValues.upazila_id || ''}
                        disabled={!selectedValues.district_id || loadingUpazila}
                        onChange={e => {
                            onChange('upazila_id', e.target.value);
                            onChange('local_government_id', '');
                            onChange('ward_id', '');
                        }}
                        className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white disabled:bg-slate-100 disabled:text-slate-400"
                    >
                        <option value="">উপজেলা নির্বাচন করুন</option>
                        {upazilas.map(u => (
                            <option key={u.id} value={u.id}>{u.name_bn}</option>
                        ))}
                    </select>
                    {errors.upazila_id && <p className="text-xs text-red-600 mt-1">{errors.upazila_id}</p>}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                {/* Local Government */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                        <span>সিটি কর্পোরেশন / পৌরসভা / ইউনিয়ন</span>
                        {loadingLocalGov && <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />}
                    </label>
                    <select
                        value={selectedValues.local_government_id || ''}
                        disabled={!selectedValues.upazila_id || loadingLocalGov}
                        onChange={e => {
                            onChange('local_government_id', e.target.value);
                            onChange('ward_id', '');
                        }}
                        className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white disabled:bg-slate-100 disabled:text-slate-400"
                    >
                        <option value="">প্রতিষ্ঠান নির্বাচন করুন</option>
                        {localGovs.map(lg => (
                            <option key={lg.id} value={lg.id}>{lg.name_bn}</option>
                        ))}
                    </select>
                </div>

                {/* Ward */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                        <span>ওয়ার্ড নম্বর (যদি প্রযোজ্য হয়)</span>
                        {loadingWard && <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />}
                    </label>
                    <select
                        value={selectedValues.ward_id || ''}
                        disabled={!selectedValues.local_government_id || loadingWard}
                        onChange={e => onChange('ward_id', e.target.value)}
                        className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white disabled:bg-slate-100 disabled:text-slate-400"
                    >
                        <option value="">ওয়ার্ড নির্বাচন করুন</option>
                        {wards.map(w => (
                            <option key={w.id} value={w.id}>{w.name_bn}</option>
                        ))}
                    </select>
                </div>

                {/* Specific Area / Village */}
                <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                        নির্দিষ্ট এলাকা / গ্রাম / মহল্লা
                    </label>
                    {areas.length > 0 ? (
                        <select
                            value={selectedValues.area_id || ''}
                            onChange={e => onChange('area_id', e.target.value)}
                            className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white"
                        >
                            <option value="">এলাকা নির্বাচন করুন</option>
                            {areas.map(a => (
                                <option key={a.id} value={a.id}>{a.name_bn}</option>
                            ))}
                        </select>
                    ) : (
                        <input
                            type="text"
                            placeholder="যেমন: হাসপাতাল মোড়, বাজার রোড"
                            value={selectedValues.specific_location_details || ''}
                            onChange={e => onChange('specific_location_details', e.target.value)}
                            className="w-full rounded-lg border-slate-300 shadow-xs text-sm focus:border-emerald-500 focus:ring-emerald-500 py-2.5 px-3 bg-white"
                        />
                    )}
                </div>
            </div>
        </div>
    );
}
